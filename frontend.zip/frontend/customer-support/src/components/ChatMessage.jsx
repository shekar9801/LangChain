import ChatbotIcon from "./ChatbotIcon";
import { User } from "lucide-react"; // or any other icon library you like

const ChatMessage = ({ chat }) => {
  return (
    <div className={`message ${chat.role === "model" ? "bot" : "user"}-message`}>
      {/* Show bot icon if role = model */}
      {chat.role === "model" && <ChatbotIcon />}
      
      {/* Show user icon if role = user */}
      {chat.role === "user" && (
        <div className="user-icon">
          <User size={20} />  
        </div>
      )}

      <p className="message-text">{chat.text}</p>
    </div>
  );
};

export default ChatMessage;
