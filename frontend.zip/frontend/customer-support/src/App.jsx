import React, { useRef, useEffect, useState } from "react";
import ChatbotIcon from "./components/ChatbotIcon";
import ChatForm from "./components/ChatForm";
import ChatMessage from "./components/ChatMessage";

const App = () => {
  const [chatHistory, setChatHistory] = useState([]);
  const [showChatBot, setShowChatBot] = useState(false); // ✅ should be boolean, not []

  const chatBodyRef = useRef();

  const generateBotResponse = async (history) => {
    try {
      const lastMessage = history[history.length - 1].text;

      // Temporary "Thinking..." message
      setChatHistory((prev) => [
        ...prev,
        { role: "model", text: "Thinking..." },
      ]);

      const response = await fetch("http://localhost:5000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: lastMessage }),
      });

      const data = await response.json();

      // Replace "Thinking..." with actual response
      setChatHistory((prev) => [
        ...prev.slice(0, -1),
        { role: "model", text: data.model },
      ]);
    } catch (error) {
      console.error("Error generating bot response:", error);
      setChatHistory((prev) => [
        ...prev.slice(0, -1),
        { role: "model", text: "Error connecting to bot." },
      ]);
    }
  };

  // Auto-scroll to bottom on new message
  useEffect(() => {
    if (chatBodyRef.current) {
      chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
    }
  }, [chatHistory]);

  return (
    <div className={`container ${showChatBot ? "show-chatbot" : ""}`}>
      {/* Toggle Button */}
      <button onClick={() => setShowChatBot((prev) => !prev)} id="chat-toggler">
        <span className="material-symbols-outlined">mode_comment</span>
        <span className="material-symbols-outlined">close</span>
      </button>

      {/* Chat Popup */}
      {showChatBot && (
        <div className="chatbot-popup">
          <div className="chat-header">
            <div className="header-info">
              <ChatbotIcon />
              <h2 className="logo-text">Chatbot</h2>
            </div>
            <button
              onClick={() => setShowChatBot(false)}
              className="material-symbols-outlined"
            >
              keyboard_arrow_down
            </button>
          </div>

          <div ref={chatBodyRef} className="chat-body">
            <div className="message bot-message">
              <ChatbotIcon />
              <p className="message-text">
                Hello! How can I assist you today?
              </p>
            </div>
            {chatHistory.map((chat, index) => (
              <ChatMessage key={index} chat={chat} />
            ))}
          </div>

          <div className="chat-footer">
            <ChatForm
              chatHistory={chatHistory}
              setChatHistory={setChatHistory}
              generateBotResponse={generateBotResponse}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
