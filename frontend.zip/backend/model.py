from flask import Flask, request, jsonify
from flask_cors import CORS   # type: ignore
from langchain_ollama import ChatOllama  # type: ignore

app = Flask(__name__)
CORS(app)  

llm = ChatOllama(model="gemma3:270m",base_url="http://localhost:11434")

@app.route("/", methods=["GET"])
def home():
    return "Ollama Chat API is running! Use /chat endpoint."

@app.route("/chat", methods=["GET", "POST"])
def chat():
    try:
        if request.method == "GET":
            user_message = request.args.get("message", "").strip()
            if not user_message:
                return jsonify({"error": "Please provide ?message=your_text"}), 400
            
            response = llm.invoke(user_message)
            return jsonify({"user": user_message, "model": response.content})

        if request.method == "POST":
            data = request.get_json(silent=True)
            if not data or "message" not in data:
                return jsonify({"error": "No 'message' field in JSON body"}), 400
            
            user_message = data["message"].strip()
            response = llm.invoke(user_message)
            return jsonify({"user": user_message, "model": response.content})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
